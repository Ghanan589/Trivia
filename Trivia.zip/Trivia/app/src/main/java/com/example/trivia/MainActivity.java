package com.example.trivia;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {


    private ActivityResultLauncher<Intent> launcher;

    private FbModule fbModule;
    private String backgroundcolor="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fbModule=new FbModule(this);

        launcher=registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult o) {
                        if(o.getResultCode()==RESULT_OK)
                        {
                            Intent data = o.getData();
                            String str = data.getStringExtra("color");
                            Toast.makeText(MainActivity.this, "" + str, Toast.LENGTH_SHORT).show();
                            fbModule.writeBackgroundColorToFb(str);
                        }

                    }
                }
        );//נרשם כדי לקבל מידע מהאקטיביטי
    }

    public void onStartGame(View view) {
    }

    public void onSetting(View view) {
        Intent i = new Intent(this,SettingActivity.class);
        launcher.launch(i);
    }

    public void onInstruction(View view) {
    }

    public void setNewColorFromFB(String str) {
        this.backgroundcolor = str;
        Toast.makeText(this, backgroundcolor, Toast.LENGTH_SHORT).show();
    }
}